package com.maven;

public class Matematica {

    private int[] pOperadores;

    public Matematica(int[] args) {
        if(args != null)
            if(args.length > 0)
                this.pOperadores = args;
    }

    protected boolean isNull(){
        return this.pOperadores != null; // ? true : false
    }

    public int count(){
        return this.isNull() ? 0 : this.pOperadores.length;
    }

    public int getItem(int nIndex){
        return this.isNull() ? 0 : this.pOperadores[nIndex];
    }

    public Integer fxSumar(){
        Integer nReturn;

        nReturn = 0;

        if(!this.isNull()){
            for(int i = 0; i < this.count(); i++)
                nReturn = this.getItem(i);
        }

        return nReturn;
    }

    public Integer fxPoducto(){
        Integer nReturn;

        nReturn = 0;

        if(!this.isNull()){
            for(int i = 0; i < this.count(); i++)
                nReturn *= this.getItem(i);
        }

        return nReturn;
    }
}
