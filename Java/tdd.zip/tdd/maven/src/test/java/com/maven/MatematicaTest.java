package com.maven;

import com.maven.Matematica;

public class MatematicaTest {

    @Test
    public void fxSumar(){
        // Resultados
        int nEsperado = 11;
        int nTesteando[] = {4, 5, 2};

        Matematica m = new Matematica(nTesteando);

    }
}
